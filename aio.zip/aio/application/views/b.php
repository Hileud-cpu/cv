<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container-fluid"> 
<center>   
  <table class="table table-bordered">
    <thead>
     	<tr align="center" bgcolor="green">
				<th>No</th>
				<th>Legend</th>
				<th>Kegunaan</th>				
			</tr>
		</thead
		<tbody>
			<tr align="center">
				<td>1</td>
				<td>Daftar Arsip</td>
				<td>Daftar Kumpulan Arsip</td>
			</tr>
			<tr align="center">
				<td>2</td>
				<td>Upload Arsip</td>
				<td>Untuk mengunggah file arsip manual ke digital</td>
			</tr>
			<tr align="center">
				<td>3</td>
				<td>Download Arsip</td>
				<td>Untuk mengunduh/mengambil arsip digital yang sudah ada</td>
			</tr>
			<tr align="center">
				<td>4</td>
				<td>Request Alih Media</td>
				<td>Untuk mengunduh arsip</td>
			</tr>
			<tr align="center">
				<td>5</td>
				<td>List Data-Data Arsip</td>
				<td>Urutan arsip</td>
			</tr>
    </tbody>
  </table>
</div>
</body>
</html>
 