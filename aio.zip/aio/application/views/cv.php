<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hangover</title>
<meta name="description" content="">
<meta name="author" content="">

<!-- Favicons
    ================================================== -->
<link rel="shortcut icon" href="img/fav.png" type="image/png">

<!-- Bootstrap -->
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">

<!-- Stylesheet
    ================================================== -->
<link rel="stylesheet" type="text/css"  href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/nivo-lightbox/nivo-lightbox.css">
<link rel="stylesheet" type="text/css" href="css/nivo-lightbox/default.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800,600,300' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/modernizr.custom.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
<!-- Navigation
    ==========================================-->
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand page-scroll" href="#page-top"><i class="fa fa-play fa-code"></i> Hangover</a> </div>
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#page-top" class="page-scroll">Home</a></li>
        <li><a href="#about" class="page-scroll">About</a></li>
        <li><a href="#portfolio" class="page-scroll">Portfolio</a></li>
        <li><a href="#contact" class="page-scroll">Contact</a></li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<!-- Header -->
<header id="header">
  <div class="intro">
    <div class="container">
      <div class="row">
        <div class="intro-text">
          <h1>Biodata</h1>
<!-- Membuat huruf menjadi besar (Ukuran H2) -->
<table width="800px"> <!-- Membuat sebuah table -->
<tr>
          <td width="25%">Nama</td>
          <td width="1%">:</td>
          <td><b>Arya Lesmana</b></td>
          <td rowspan="5"><img src="8Fcd0bji.jpg" alt="Foto" title="Foto" height="100px" width="75px"></td>
        </tr>
<tr>
          <td>Tempat/Tanggal lahir </td>
          <td>:</td>
          <td>Bandung,16 Maret 2002</td>
        </tr>
<tr>
          <td>Alamat</td>
          <td>:</td>
          <td>Jl.Ligar Resik Kp.Jiwanya Rt:02 Rw:04</td>
        </tr>
<tr>
    <td>E-mail</td>
          <td>:</td>
          <td>lesmanaarya092@gmail.com</td>
        </tr>
</tbody>
    </table>
<!-- About Section -->
<h1>Sekolah</h1>
<div id="about">
  <table width="800px">
      <tbody>
<tr>
          <td width="25%">2007-2008</td>
          <td width="1%">:</td>
          <td>TK AL BURHAN</td>
        </tr>
<tr>
          <td>2008-20014</td>
          <td>:</td>
          <td>SDN CIGADUNG 2</td>
        </tr>
<tr>
          <td>2014-2017</td>
          <td>:</td>
          <td>SMP NASIOANL BANDUNG</td>
<tr>
          <td>2017-present</td>
          <td>:</td>
          <td>SMK AL FALAH BANDUNG</td>
        </tr>
</tr>
</table>
<!-- Portfolio Section -->

<script type="text/javascript" src="js/jquery.1.11.1.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/SmoothScroll.js"></script> 
<script type="text/javascript" src="js/nivo-lightbox.js"></script> 
<script type="text/javascript" src="js/jquery.isotope.js"></script> 
<script type="text/javascript" src="js/jqBootstrapValidation.js"></script> 
<script type="text/javascript" src="js/contact_me.js"></script> 
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>