<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CV Dika Arief Sugiyatna</title>
  <meta name="description" content="simple CV example created with HTML and CSS">
  <meta name="author" content="Fly Nerd">
  <link rel="icon" href="./img/favicon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <div>
       <img src="./img/1.jpg" />
    </div>
    <h1>Dika Arief Sugiyatna</h1>
    <section>
      <p>Hai Nama saya DIKA ARIEF SUGIYATNA saya adalah seorang pelajar di SEKOLAH MENGAH KEJURUAN AL FALAH DAGO BANDUNG, saya berusia 17 tahun lahir di BANDUNG 23 Mei 2002, Hobi saya adalah membaca tentang ilmu politik dan saintek, Saya beralamatkan di Jl.Tubagus Ismail Bandung Jawa Barat,</p>
      <a href="https://www.facebook.com/flynerdpl/" target="_blank">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="https://www.twitter.com/flynerdpl/" target="_blank">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="https://github.com/ritaly" target="_blank">
        <i class="fab fa-github-alt"></i>
      </a>
      <a href="https://www.instagram.com/flynerdpl/" target="_blank">
        <i class="fab fa-instagram"></i>
      </a>
      <a href="https://www.linkedin.com/in/ritalyczywek/" target="_blank">
        <i class="fab fa-linkedin-in"></i>
      </a>
    </section>
  </header>
  <main>
    <section>
      <h3>Indentitas Lengkap Saya</h3>
      <article class='course'>
        <div class='title'>
          <h4>Nama</h4>
        </div>
        <div class="descrition">
          <p>Dika Arief Sugiyatna</p>
        </div>
      </article>
      <article class='course'>
        <div class='title'>
          <h4>Tempat Tanggal Lahir</h4>
        </div>
        <div class="descrition">
          <p>Bandung, 23 Mei 2002</p>
        </div>
      </article>
      <article class='course'>
        <div class='title'>
          <h4>Alamat</h4>
        </div>
        <div class="descrition">
          <p>Jl.Tubagus Ismail Dalam Rt.04 Rw.07 Kelurahan Sekeloa Kecamatan Coblong Kota Bandung Jawa Barat</p>
        </div>
      </article>
      <article class='course'>
        <div class='title'>
          <h4>Jenis Kelamin</h4>
        </div>
        <div class="descrition">
          <p>Laki Laki</p>
        </div>
      </article>
      <article class='course'>
        <div class='title'>
          <h4>Alamameter</h4>
        </div>
        <div class="descrition">
          <p>Institut Teknologi Bandung</p>
        </div>
      </article>
    </section>
    <section>
      <h3>Skills</h3>
      <div class='skills'>
        <div class='column'>
          <h4>Good knowledge</h4>
          <ul>
            <li>HTML5</li>
            <li>CSS</li>
            <li>JavaScript ES5/6</li>
            <li>SQL</li>
          </ul>
        </div>
        <div class='column'>
          <h4>Basic knowledge</h4>
          <ul>
            <li>jQuery</li>
            <li>NodeJS</li>
            <li>MongoDB</li>
            <li>Django</li>
          </ul>
        </div>
        <div>
          <h4>Bahasa</h4>
          <p> Indonesia - Bahasa Formal</p>
          <p> Sunda - Bahasa Sapopoe</p>
          
        </div>
      </div>
    </section>

    <section>
      <h3>Sekolah</h3>
      <article>
        <div class='school'>
          <span>2007-2013</span> <strong>Sdn Sekeloa 2 Bandung</strong>
        </div>
        <div class="descrition">
          Lulusan baik
        </div>
      </article>
      <article>
        <div class='school'>
          <span>2014-2017</span> <strong>Smp Al Falah Dago Bandung</strong>
        </div>
        <div>
          Lulusan Terbaik
        </div>
      </article>
      <article>
        <div class='school'>
          <span>2017-2020</span> <strong>Smk Al Falah Dago Bandung</strong>
        </div>
        <div class="descrition">
          Summer Cumlaude
        </div>
      </article>
    </section>
    <section>
      <h3>Praktik Kerja Lapangan</h3>
      <article>
        <div class='Praktik Kerja Lapangan'>
          <span>04.2019 - 06.2019</span> <strong>DPKP3 Bandung</strong><br> <strong>Jabatan:</strong> Staff Di Bidang Pertanahan DPKP3 </div> <div>
            
          </ul>
        </div>
      </article>
    </section>
  </main>
  <footer>
    <p>Created by: Dika Arief Sugiyatna</a> / 2019 </p>
  </footer>
</body>
</html>
